#!/bin/bash
set -euo pipefail

CONTAINER_NAME="sample-nginx"

print_usage() {
  echo "Usage: $0 {kill-container|block-port|unblock-port|fill-disk|clean-disk|curl-status|all}"
}

simulate_kill_container() {
  echo "[SIMULATING FAILURE] Killing Docker container '${CONTAINER_NAME}'..."
  docker kill "${CONTAINER_NAME}" || true
  echo "Container killed. Monitor will trigger Tier 1 restart on next check."
}

simulate_block_port() {
  echo "[SIMULATING FAILURE] Dropping incoming port 80 traffic via iptables..."
  sudo iptables -I INPUT 1 -p tcp --dport 80 -j DROP
  echo "Port 80 blocked. HTTP & TCP probes will timeout."
}

simulate_unblock_port() {
  echo "Restoring port 80 connectivity..."
  sudo iptables -D INPUT -p tcp --dport 80 -j DROP || true
  echo "Traffic restored."
}

simulate_fill_disk() {
  echo "[SIMULATING FAILURE] Filling disk with 5GB temp file..."
  sudo fallocate -l 5G /tmp/disk_fill_test.img || dd if=/dev/zero of=/tmp/disk_fill_test.img bs=1M count=5000
  df -h /
}

simulate_clean_disk() {
  echo "Cleaning up temporary disk fill file..."
  sudo rm -f /tmp/disk_fill_test.img
  df -h /
}

query_status() {
  curl -s http://localhost:8080/status | jq . || curl -s http://localhost:8080/status
}

case "${1:-}" in
  kill-container) simulate_kill_container ;;
  block-port)     simulate_block_port ;;
  unblock-port)   simulate_unblock_port ;;
  fill-disk)      simulate_fill_disk ;;
  clean-disk)     simulate_clean_disk ;;
  curl-status)    query_status ;;
  *) print_usage; exit 1 ;;
esac